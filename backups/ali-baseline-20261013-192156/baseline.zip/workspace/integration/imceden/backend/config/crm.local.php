<?php
return array('enabled'=>true,'demo_mode'=>false,'messaging_enabled'=>false,'ai_enabled'=>false,'write_profiles'=>array(1));
