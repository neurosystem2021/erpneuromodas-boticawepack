import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  base: '/crm/dist/',
  build: { outDir: 'dist', emptyOutDir: true }
})
