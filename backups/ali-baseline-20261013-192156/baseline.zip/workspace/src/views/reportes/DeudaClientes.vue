<template>
<div class="nst-screen nst-screen--deudaclientes">
  <h2 align-h="center" class="text-center" >Reporte Deuda de Clientes</h2>
    <b-container class="bv-example-row">
      <section class="nst-panel nst-panel--filters"><b-row>
        <b-col md="4" class="my-1">
          <b-form-group>
                <label>Buscar:</label>
            
            <b-input-group>
              <b-form-input v-model="filter" placeholder="Buscar" @input="currentPage = 1" />
              <b-input-group-append>
                <b-btn :disabled="!filter" @click="filter = ''">Limpiar</b-btn>
              </b-input-group-append>
            </b-input-group>
          </b-form-group>
          <br />
        </b-col>
        <b-col md="4">
          <b-form-group>
                <label>Almacen:</label>
                <autocomplete
                    required="required"
                    ref="inputAlmacen"
                    :url="API + 'almacenes'"
                    anchor="Almacen"
                    initValue=""
                    label="writer"
                    placeholder=""
                    :on-select="setAlmacen" 
                    :onFocus="focusAutocomplete.bind(null, 'inputAlmacen')"
                    :classes="{input: 'form-control'}">
                </autocomplete>
              </b-form-group>
        </b-col>
        <b-col md="4" class="my-1">
          <b-row>
          <b-col md="8">

            <b-form-group>
                <label>Mostrar:</label>
              <b-form-select :options="pageOptions" v-model="perPage" @input="currentPage = 1"/>
            </b-form-group>
          </b-col>
          <b-col md="4">
           <!-- <p style="margin-top: 6px;">de <b class="text-success">{{ this.totalRows }}</b> Artículos</p>-->
          </b-col>
          </b-row>
        </b-col>

        <b-table small
          ref="tablaProductos"
          :filter="filter"
          :sort-by.sync="sortBy"
          :sort-desc.sync="sortDesc"
          striped
          hover
          id="my-table" 
          :busy.sync="isBusy" 
          :items="myProvider" 
          :fields="fields"
          :per-page="perPage"
          :current-page="currentPage" responsive="" show-empty empty-text="No hay registros para los filtros seleccionados." empty-filtered-text="No se encontraron coincidencias." >
          <template slot="action"  slot-scope="data">
             <pago-deuda @registro="recargarTabla" :Cliente="data.item"> </pago-deuda>
          </template> 
        </b-table>
          <b-row>
              <b-col md="6" class="my-1">
                  <b-pagination :total-rows="totalRows" :per-page="perPage" v-model="currentPage" class="my-0" />
              </b-col>
          </b-row>
      </b-row></section>
      <b-row align-h="center" class="text-center nst-action-bar">
          <b-col cols="4">
            <b-button variant="success" size="lg" :href="'/api/index.php/reporte/deudaclientes2?idalmacen=' + almacen.IdAlmacen" target="_blank">Exportar</b-button>
          </b-col>
      </b-row>
      <br /><br />
    </b-container>
</div>
</template>

<script>
import config from "@/store/config.js";
import PagoDeuda from "@/components/PagoDeuda";
// import DetalleDeudaCliente from '@/components/DetalleDeudaCliente.vue'
// import ProductoForm from '@/components/ProductoForm'

export default {
  mounted() {
    this.axios
      .get(
        this.API + "clientes/deuda/count?idalmacen=" + this.almacen.IdAlmacen
      )
      .then(response => {
        console.log(response);
        this.totalRows = response.data.total;
      });
  },
  data() {
    return {
      API: config.API,
      pageOptions: [5, 10, 15, 50, 100],
      filter: "",
      sortBy: "IdDocVenta",
      sortDesc: false,
      items: [],
      isBusy: false,
      fields: [
        { key: "DniRuc", label: "DNI/RUC", sortable: true },
        { key: "Cliente", label: "Cliente", sortable: true },
        { key: "Correlativo", label: "Serie", sortable: true },
        { key: "Total", label: "Total", sortable: true },
        { key: "Aplicado", label: "Aplicado", sortable: true },
        { key: "NotaCreApli", label: "Apli. Nota Cred.", sortable: true },
        { key: "Saldo", label: "Saldo", sortable: true },
        { key: "FechaDoc", label: "Emision", sortable: true },
        { key: "FechaCredito", label: "Vencimiento", sortable: true },
        { key: "action", label: "", sortable: false }
      ],
      totalRows: 50,
      perPage: 10,
      currentPage: 1,
      almacen: {
        IdAlmacen: 1
      }
    };
  },
  methods: {
    focusAutocomplete(ref) {
      // this.$refs[ref].type = ""
      this.$refs[ref].handleDoubleClick();
    },
    pagarDeuda(IdCliente) {
      console.log("IdCliente", IdCliente);
    },
    recargarTabla() {
      setTimeout(() => {
        Vue.nextTick(() => this.$refs.tablaProductos.refresh());
      }, 100);
    },
    setAlmacen(obj) {
      this.almacen = obj;
      Vue.nextTick(() => this.$refs.tablaProductos.refresh());
    },
    myProvider(ctx) {
      // Here we don't set isBusy prop, so busy state will be handled by table itself
      // this.isBusy = true
      // console.log(ctx.filter)
      // let url = this.API + 'productos/stock?idAlmacen='+this.almacen.IdAlmacen+'&limit='+ctx.perPage+'&page='+ctx.currentPage+'&filter[producto]='+ (ctx.filter||'')+'&filter[minimo]=1&sortBy='+ctx.sortBy
      // url += '&sortDesc='+(ctx.sortDesc ? 1 : 0 )
      let promise = this.axios.get(
        this.API +
          "cliente/deudas?idalmacen=" +
          this.almacen.IdAlmacen +
          "&q=" +
          ctx.filter +
          "&limit=" +
          ctx.perPage +
          "&page=" +
          ctx.currentPage
      );

      return promise
        .then(response => {
          console.log(response);
          this.items = response.data;
          //this.totalRows = this.items.length
          // Here we could override the busy state, setting isBusy to false
          // this.isBusy = false
          return this.items;
        })
        .catch(error => {
          // Here we could override the busy state, setting isBusy to false
          // this.isBusy = false
          // Returning an empty array, allows table to correctly handle busy state in case of error
          return [];
        });
    }
  },
  components: {
    // ProductoForm
    // DetalleDeudaCliente,
    PagoDeuda
  }
};
</script>

<style>
</style>
