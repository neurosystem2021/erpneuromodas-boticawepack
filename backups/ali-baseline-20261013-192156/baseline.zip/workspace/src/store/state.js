export default {
    proveedoresFiltrados : [],
    almacenesFiltrados: []
} 
