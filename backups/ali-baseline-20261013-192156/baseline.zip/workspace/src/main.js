import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import './assets/css/global.css'
import BootstrapVue from 'bootstrap-vue'
import Autocomplete from 'vue2-autocomplete-js'
import axios from 'axios';
import VueAxios from 'vue-axios'
import Toasted from 'vue-toasted';
import VueMoment from 'vue-moment'
import { detect } from 'detect-browser';
import VueQuagga from "vue-quaggajs";
import VueBarcodeScanner from "vue-barcode-scanner";

import VueSweetalert2 from 'vue-sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
 import { io } from 'socket.io-client'
const browser = detect();

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import '../static/vue2-autocomplete.css'
import '../static/styles.css'
import 'leaflet/dist/leaflet.css';
Vue.prototype.$browser = detect()

Vue.config.productionTip = false
Vue.use(VueSweetalert2)
Vue.use(VueAxios, axios)
Vue.use(Toasted, {
  theme: "bubble",
  position: "top-center",
  duration : 3000
})

Vue.use(BootstrapVue);
Vue.use(VueMoment);
Vue.use(VueQuagga);
Vue.use(VueBarcodeScanner);

// Componentes 
Vue.component('autocomplete', Autocomplete)
Vue.component('editable',{
  template:'<div contenteditable="true" @input="update"></div>',
  props:['content'],
  mounted:function(){
    this.$el.innerText = this.content;
  },
  methods:{
    update:function(event){
      this.$emit('update',event.target.innerText);
    }
  }
})
const socket = io('https://panel.pedi2.pe',{
  // TRANSPORTE
  transports: ['websocket', 'polling'],     // WebSocket primero, fallback a polling
  
  // SSL/TLS
  secure: true,                              // Usar wss:// (WSS seguro)
  rejectUnauthorized: false,                // Aceptar certificados autofirmados
  
  // RECONEXIÓN
  reconnection: true,                        // Reconectar si se desconecta
  reconnectionDelay: 1000,                  // Esperar 1s antes de reconectar
  reconnectionDelayMax: 5000,               // Máximo 5s entre intentos
  reconnectionAttempts: Infinity,           // Intentos infinitos
  
  // CONEXIÓN AUTOMÁTICA
  autoConnect: false,                       // NO conectar al cargar (manual)
  
  // OTROS
  forceNew: false,                          // Reutilizar conexión existente
  multiplex: true                           // Permitir múltiples conexiones
})
Vue.prototype.$socket = socket

Vue.filter('redondear', (value, length) => {
  return parseFloat(value || 0).toFixed(length || 2)
})
Vue.filter('redondeoMayor', (value) => {
  return Math.ceil(value || 0)
})
Vue.filter('redondeoMenor', (value) => {
  return Math.floor(value || 0)
})
Vue.filter('moneda', value => {
  return parseFloat(value || 0).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')
})


window.Vue = Vue


/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})

import './legacy-migrations/remision-modern.css'
import './legacy-migrations/remision-modern.js'
