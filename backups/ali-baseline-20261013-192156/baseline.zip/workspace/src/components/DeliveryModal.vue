<template>
<div>
    <b-button block @click="show=true" variant="info" class="btnAction" size="md" v-bind:class="{ parpadea: pedidos.length>0}"> <img src="static/logo.png" style="width: 24px" /> Delivery Pedi2.pe</b-button>
    <b-modal id="modalPedidos" 
        title="DELIVERY PEDI2.PE"
        size="lg" v-model="show"
        header-bg-variant="primary"
        headerTextVariant="light"
        body-bg-variant="light"
        body-text-variant="dark"
        centered 
        ok-only no-close-on-backdrop
        no-close-on-esc ok-title="Cerrar" modal-class="nst-dialog" body-class="nst-dialog-body" footer-class="nst-dialog-footer">           
        <b-container fluid style="width: calc(100% - 50px)" class="bv-example-row" id="conten">
            <div>
            <b-row>
                <b-col md="7">
                    <h2>Lista de pedidos: <b-button variant="outline-info" @click="getPedidos">Actualizar Lista</b-button></h2>
                    <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col" class="text-center">Código</th>
                        <th scope="col" class="text-center">Estado</th>
                        <th scope="col" class="text-center">Cliente</th>
                        <th scope="col" class="text-center">Motorizado</th>
                        <th scope="col" class="text-center">Acciones</th>
                        </tr>
                    </thead>
                        <tbody v-for="(pedido, index) in pedidos" :key="index">
                            <tr>
                                <td scope="row" class="text-center font-weight-bold">{{ pedido.IdPedido }}</td>
                                <td v-if="pedido.Estado=='E'" class="text-center"><b-badge variant="dark">EN ESPERA</b-badge></td>
                                <td v-else-if="pedido.Estado=='PE'" class="text-center"><b-badge variant="success">PREPARANDO</b-badge></td>
                                <td v-else-if="pedido.Estado=='PU'" class="text-center"><b-badge variant="primary">CAMINO AL CLIENTE</b-badge></td>
                                <td v-else-if="pedido.Estado=='UC'" class="text-center"><b-badge variant="primary">EN LA UBICACION DEL CLIENTE</b-badge></td>
                                <td v-else class="text-center"><b-badge variant="danger">FINALIZADO</b-badge></td>
                                <td class="text-center"><b>{{ pedido.Cliente }}</b></td>
                                <td v-if="pedido.IdMotorizado==null" class="text-center"><b-badge variant="danger">NO ASIGNADO</b-badge></td>    
                                <td v-else class="text-center"><b>{{ pedido.Motorizado }}</b></td>
                                <td class="text-center">
                                    <b-button variant="success" size="sm" v-b-toggle="''+pedido.IdPedido"><i class="fas fa-eye"></i></b-button>
                                    <b-button v-show="pedido.Estado!='E'" :id="'popover-motorizado' + pedido.IdPedido" variant="warning" size="sm" @click="getMotorizados(pedido.IdPedido)"><i class="fas fa-bicycle"></i></b-button>
                                    <b-popover :show.sync="pedido.showPopover" :target="'popover-motorizado' + pedido.IdPedido" :title="'Asignar motorizado al pedido : '+pedido.IdPedido">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <td class="text-center"><b>Nombre</b></td>
                                                    <td class="text-center"><b>Estado</b></td>
                                                    <td class="text-center"><b>Línea</b></td>
                                                    <td class="text-center"><b>Asignación</b></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="(motorizado, index) in motorizados" :key="index" style="border-top: 1px solid black; border-bottom: 1px solid black;">
                                                    <td class="text-center font-weight-bold">{{motorizado.Motorizado}}</td>

                                                    <td v-if="motorizado.ContadorViajes>0">
                                                        <b-badge v-if="motorizado.IdMotorizado==pedido.IdMotorizado" variant="danger" class="text-center">EN ESTE VIAJE</b-badge>
                                                        <b-badge v-else variant="warning" class="text-center">EN OTRO VIAJE</b-badge>
                                                    </td>

                                                    <td v-else>
                                                        <b-badge variant="success" class="text-center">LIBRE</b-badge>     
                                                    </td>

                                                    <td v-if="motorizado.online" class="text-center"><b-badge variant="success">online</b-badge></td>
                                                    <td v-else><b-badge variant="secondary" class="text-center">offline</b-badge></td>

                                                    <td v-if="motorizado.IdMotorizado==pedido.IdMotorizado" class="text-center">
                                                        <label>-------</label>
                                                    </td>
                                                    <td v-else>
                                                        <b-button v-if="pedido.IdMotorizado== null" variant="success" size="sm" @click="asignarMotorizado(pedido.IdPedido,pedido.IdCliente,pedido.Cliente,motorizado.IdMotorizado,motorizado.Motorizado)">Asignar</b-button>
                                                        <b-button v-else variant="warning" size="sm" @click="cambiarMotorizado(pedido.IdPedido,pedido.IdCliente,pedido.Cliente,motorizado.IdMotorizado,motorizado.Motorizado,pedido.IdMotorizado,pedido.Motorizado)">Cambiar</b-button>
                                                    </td>         
                                                </tr>
                                            </tbody>
                                        </table>
                                    </b-popover>
                                    <b-button size="sm" v-if="pedido.Estado!='F'" variant="info" @click="mostrarClienteMapa(pedido.IdPedido)"><i class="fas fa-map-marker-alt"></i></b-button>
                                    <b-button size="sm" v-if="pedido.Estado!='E'" variant="danger" @click="cancelarPedido(pedido.IdPedido,pedido.IdCliente)"><i class="fas fa-times fa-lg"></i></b-button>
                                </td>
                            </tr>
                            <tr> 
                                <td colspan="5">
                                    <b-collapse :id="''+pedido.IdPedido" class="mt-1">
                                        <b-card>
                                            <b-row>
                                                <b-col md="11">
                                                    <label>Cliente: <span class="font-weight-bold">{{pedido.Cliente}}</span></label>
                                                    <br>  
                                                    <label>Teléfono del cliente: <span class="font-weight-bold">{{pedido.TelefonoCliente}}</span></label>
                                                    <br>
                                                    <label>Dirección: <span class="font-weight-bold">{{pedido.Direccion}}</span></label>
                                                    <br>
                                                    <label>Referencia: <span class="font-weight-bold"> {{pedido.Referencia}}</span></label>
                                                    <br>
                                                    <label>Método de Pago: <span class="font-weight-bold">{{pedido.MetodoPago}}</span></label>
                                                    <br>
                                                    <label>Fecha y Hora de solicitud: <span class="font-weight-bold">{{$moment(pedido.FechaReg).format("YYYY-MM-DD HH:mm:ss")}}</span></label> 
                                                </b-col>
                                                <b-col md="1">
                                                    <i v-b-toggle="''+pedido.IdPedido" class="fas fa-minus" style='font-size:26px;color:gray; cursor: pointer;'></i>
                                                </b-col>
                                            </b-row>
                                            <br>
                                            <b-alert show variant="info" style="font-weight:bold">Productos</b-alert>
                                            <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                <th scope="col" class="text-center">#</th>
                                                <th scope="col" class="text-center">Producto</th>
                                                <th scope="col" class="text-center">Cantidad</th>
                                                <th scope="col" class="text-center">Precio</th>
                                                <th scope="col" class="text-center">Sub. Total</th>
                                                <th scope="col" class="text-center">Indicaciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- <tr v-for="(detalle, index2) in JSON.parse(pedido.Productos)" :key="index2"> -->
                                                <tr v-for="(detalle, index2) in pedido.Productos" :key="index2">
                                                    <td scope="row" class="text-center" style="text-align: center; vertical-align: middle;">{{ index2 + 1}}</td>
                                                    <td scope="row" class="text-center font-weight-bold" style="width:25% !important; font-size:0.8rem">{{ detalle.Producto }}</td>
                                                    <td scope="row" class="font-weight-bold" style="text-align: center; vertical-align: middle;">{{ detalle.Cantidad }}</td>
                                                    <td scope="row" class="font-weight-bold" style="text-align: center; vertical-align: middle;">S/ {{ detalle.Precio.toFixed(2) }}</td>
                                                    <td scope="row" class="font-weight-bold" style="text-align: center; vertical-align: middle;">S/ {{ (detalle.Precio * detalle.Cantidad ).toFixed(2) }}</td>
                                                    <td scope="row" style="text-align: center; vertical-align: middle; width: 170px;" v-if="detalle.Indicacion=='' || detalle.Indicacion==null"><b-badge variant="warning">No tiene</b-badge></td>
                                                    <td scope="row" style="text-align: center; vertical-align: middle; width: 170px;" v-else>{{ detalle.Indicacion }}</td>
                                                </tr>
                                            </tbody>
                                            </table>
                                            <label>Costo de delivery: <span class="font-weight-bold"> S/ {{pedido.PrecioDelivery}}</span></label>
                                            <br>
                                            <label>Total en productos: <span class="font-weight-bold"> S/ {{pedido.PrecioProductos}}</span></label>
                                            <br>
                                            <div class="text-center">
                                                <h2 class="font-weight-bold">Total: S/ {{ (parseFloat(pedido.PrecioDelivery)+parseFloat(pedido.PrecioProductos)).toFixed(2) }}</h2>
                                            </div>
                                            <br>
                                            <div class="text-center">
                                                <b-button v-if="pedido.Estado == 'E'" size="lg" variant="success" @click="aceptarPedido(pedido.IdPedido,pedido.IdCliente)">Aceptar</b-button>
                                                <b-button v-if="pedido.Estado == 'E'" size="lg" variant="danger" @click="rechazarPedido(pedido.IdPedido)">Rechazar</b-button>
                                                <b-button v-if="pedido.Estado != 'E'" size="lg" variant="info" @click="volverRealizarVenta(pedido.IdPedido)">Volver a Realizar Venta</b-button>
                                                <b-form-text v-if="pedido.Estado != 'E'">Si no realizo la venta del pedido, puede intentarlo nuevamente. Previamente el sistema validará que no exista una venta de este pedido.</b-form-text>
                                            </div>
                                        </b-card>
                                    </b-collapse>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </b-col>
                <b-col md="5">
                    <b-row>
                        <b-col md="12" style="margin-top:10px">
                            <b-button variant="outline-primary" @click="emitirConsultaMotorizado">Mostrar Motorizados</b-button>
                            <b-badge  variant="success" style="font-size:18px;">En Linea: {{motorizadosOnline.length}} </b-badge> 
                        </b-col>
                    </b-row>
                    <hr>
                    <b-row>
                        <b-col md="12">
                            <h4>MAPA TIEMPO REAL:
                                <b-badge v-if="mostrarMotorizados" variant="primary">MOSTRANDO MOTORIZADOS</b-badge>
                                <b-badge v-if="mostrarCliente" variant="info">{{mostrarCliente}}</b-badge>
                            </h4>
                            <div id="mapid"></div>
                        </b-col>
                    </b-row>
                </b-col>
                </b-row>
            </div>
        </b-container>
    </b-modal>
</div>
</template>
<script>
import config from "@/store/config.js";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import sound from "../../static/nuevassoli.mp3";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require("leaflet/dist/images/marker-icon-2x.png"),
  iconUrl: require("leaflet/dist/images/marker-icon.png"),
  shadowUrl: require("leaflet/dist/images/marker-shadow.png")
});

export default {
  mounted() {
    // ✅ Cambio: Configurar listeners ANTES de conectar
    this.setupSocketListeners();
    this.getEmpresaDatos();
  },

  beforeDestroy() {
    // ✅ Cambio: Remover listeners al destruir
    this.removeSocketListeners();
    this.$socket.disconnect();
    if (this.mymap) {
      this.mymap.remove();
    }
  },

  data() {
    return {
      API: config.API,
      APINODE: "https://panel.pedi2.pe",
      mymap: null,
      show: false,
      pedidos: [],
      clienteLayer: null,
      empresaLayer: null,
      titulo: "",
      infoPedido: {},
      idPedidoSelect: null,
      pedidoSelect: {
        Telefono: null,
        Direccion: null,
        Referencia: null,
        MetodoPago: null,
        FechaReg: this.$moment().format("YYYY-MM-DD HH:mm:ss"),
        IdMotorizado: null
      },
      motorizados: [],
      motorizadosOnline: [],
      mostrarMotorizados: true,
      mostrarCliente: "",
      iconMoto: L.icon({
        iconUrl: require("../../static/moto.png"),
        popupAnchor: [0, -30],
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        shadowSize: [41, 41]
      }),
      iconCasa: L.icon({
        iconUrl: require("../../static/casa.png"),
        popupAnchor: [0, -30],
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        shadowSize: [41, 41]
      }),
      idEmpresa: null,
      empresa: {},
      pedidoIdMapa: null,
      usuario: sessionStorage.getItem("User"),
      showPopover: false,
      title: "Punto de Venta",
      audio: new Audio(sound),

      // ✅ Guardar referencias de listeners
      listeners: {
        connect: null,
        disconnect: null,
        canceladoPedido: null,
        motorizadoOnline: null,
        coordsMotorizado: null,
        estadoPedido: null
      }
    };
  },

  watch: {
    show(val) {
      if (val === true) {
        this.mostrarMotorizados = true;
        this.mostrarCliente = "";
        this.pedidoMotorizadoId = null;
        this.pedidos = [];
        if (this.mymap) {
          this.mymap.remove();
        }
        setTimeout(() => {
          this.loadMapa();
        }, 500);
      }
    },
    title(val) {
      window.parent.document.title = val;
    }
  },

  methods: {
    /**
     * ✅ CONFIGURAR TODOS LOS LISTENERS
     */
    setupSocketListeners() {
      // Evento: Conectado
      this.listeners.connect = () => {
        // console.log("✅ Socket conectado");
        this.$socket.emit("conectar", {
          tipo: "PLATAFORMA",
          objeto: {
            iddb: this.empresa.IdEmpresa,
            urlplat: this.empresa.FacturaUrl,
            idalmacen: this.empresa.IdAlmacen
          }
        });
      };
      this.$socket.on("connect", this.listeners.connect);

      // Evento: Desconectado
      this.listeners.disconnect = () => {
        console.log("❌ Socket desconectado");
      };
      this.$socket.on("disconnect", this.listeners.disconnect);

      // Evento: Pedido cancelado
      this.listeners.canceladoPedido = data => {
        this.$toasted.show("Ha sido cancelado el pedido de " + data.nombre);
        if (this.pedidoIdMapa === data.idPedido) {
          this.emitirConsultaMotorizado();
        }
        this.getPedidos();
      };
      this.$socket.on("cancelado-pedido", this.listeners.canceladoPedido);

      // Evento: Motorizado online
      this.listeners.motorizadoOnline = data => {
        let motorizadosIdLista = data.map(a => a.iddb);
        let motoOnline = this.motorizadosOnline.map(a => a.iddb);

        this.motorizados.map(m => {
          let existe = motorizadosIdLista.some(ml => ml === m.IdMotorizado);
          m.online = existe;
        });

        let motorizadosFinal = [...this.motorizados];
        this.$nextTick(() => {
          this.motorizados = motorizadosFinal;
        });

        motoOnline.map(m => {
          let existe = motorizadosIdLista.some(ml => ml === m);
          if (!existe) {
            let indexmoto = this.motorizadosOnline.findIndex(a => a.iddb === m);
            if (indexmoto !== -1) {
              if (this.motorizadosOnline[indexmoto].marker != null) {
                this.mymap.removeLayer(
                  this.motorizadosOnline[indexmoto].marker
                );
              }
              this.motorizadosOnline.splice(indexmoto, 1);
            }
          }
        });
      };
      this.$socket.on("lista-on-motorizado", this.listeners.motorizadoOnline);

      // Evento: Coordenadas del motorizado
      this.listeners.coordsMotorizado = data => {
        if (this.mymap != null) {
          if (this.mostrarMotorizados) {
            let motorizadoIndex = this.motorizadosOnline.findIndex(
              m => m.iddb === data.iddb
            );
            if (motorizadoIndex === -1) {
              data.marker = new L.marker([data.lat, data.lon], {
                icon: this.iconMoto
              })
                .bindTooltip(
                  "<b style='font-size:0.8rem'>" + data.nombres + "</b>"
                )
                .openTooltip();
              data.marker.addTo(this.mymap);
              this.motorizadosOnline.push(data);
            } else {
              if (this.motorizadosOnline[motorizadoIndex].marker != null) {
                this.mymap.removeLayer(
                  this.motorizadosOnline[motorizadoIndex].marker
                );
              }
              this.motorizadosOnline[motorizadoIndex].marker = new L.marker(
                [data.lat, data.lon],
                { icon: this.iconMoto }
              )
                .bindTooltip(
                  "<b style='font-size:0.8rem'>" + data.nombres + "</b>"
                )
                .openTooltip();
              this.motorizadosOnline[motorizadoIndex].marker.addTo(this.mymap);
            }
          } else {
            if (this.pedidoMotorizadoId != null) {
              let motorizadoIndex = this.motorizadosOnline.findIndex(
                m => m.iddb === this.pedidoMotorizadoId
              );
              if (motorizadoIndex === -1) {
                data.marker = new L.marker([data.lat, data.lon], {
                  icon: this.iconMoto
                })
                  .bindTooltip(
                    "<b style='font-size:0.8rem'>" + data.nombres + "</b>"
                  )
                  .openTooltip();
                data.marker.addTo(this.mymap);
                this.motorizadosOnline.push(data);
              } else {
                if (this.motorizadosOnline[motorizadoIndex].marker != null) {
                  this.mymap.removeLayer(
                    this.motorizadosOnline[motorizadoIndex].marker
                  );
                }
                this.motorizadosOnline[motorizadoIndex].marker = new L.marker(
                  [data.lat, data.lon],
                  { icon: this.iconMoto }
                )
                  .bindTooltip(
                    "<b style='font-size:0.8rem'>" + data.nombres + "</b>"
                  )
                  .openTooltip();
                this.motorizadosOnline[motorizadoIndex].marker.addTo(
                  this.mymap
                );
              }
            } else {
              this.motorizadosOnline = [];
            }
          }
        }
      };
      this.$socket.on(
        "coordenadas-motorizado-nueva",
        this.listeners.coordsMotorizado
      );

      // Evento: Estado del pedido actualizado
      this.listeners.estadoPedido = data => {
        let indexPedido = this.pedidos.findIndex(
          p => p.IdPedido === data.idpedido
        );
        if (indexPedido !== -1) {
          this.pedidos[indexPedido].Estado = data.estado;
          if (data.estado === "F") {
            this.$toasted.success(
              "El pedido de " +
                this.pedidos[indexPedido].Cliente +
                " ha finalizado.!!"
            );
            if (this.pedidoIdMapa === data.idpedido) {
              this.emitirConsultaMotorizado();
            }
            this.getPedidos();
          }
        }
      };
      this.$socket.on(
        "estado-pedido-actualizado-plataforma",
        this.listeners.estadoPedido
      );
    },

    /**
     * ✅ REMOVER TODOS LOS LISTENERS
     */
    removeSocketListeners() {
      this.$socket.off("connect", this.listeners.connect);
      this.$socket.off("disconnect", this.listeners.disconnect);
      this.$socket.off("cancelado-pedido", this.listeners.canceladoPedido);
      this.$socket.off("lista-on-motorizado", this.listeners.motorizadoOnline);
      this.$socket.off(
        "coordenadas-motorizado-nueva",
        this.listeners.coordsMotorizado
      );
      this.$socket.off(
        "estado-pedido-actualizado-plataforma",
        this.listeners.estadoPedido
      );
    },

    loadMapa() {
      if (this.idEmpresa != null) {
        this.mymap = new L.map("mapid", {
          touchZoom: false,
          attributionControl: false,
          scrollWheelZoom: false,
          doubleClickZoom: false,
          closePopupOnClick: false
        }).setView([this.empresa.Latitud, this.empresa.Longitud], 13);

        L.tileLayer(
          "https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=sk.eyJ1IjoiamhvbndqIiwiYSI6ImNsaDBycHN6NzB3NWQzZnA3bm93bnJqdTIifQ.lu3qfaK4lH69UW9uLuGx4g",
          {
            maxZoom: 22,
            id: "mapbox/streets-v11",
            accessToken:
              "sk.eyJ1IjoiamhvbndqIiwiYSI6ImNsaDBycHN6NzB3NWQzZnA3bm93bnJqdTIifQ.lu3qfaK4lH69UW9uLuGx4g"
          }
        ).addTo(this.mymap);

        this.clienteLayer = L.layerGroup().addTo(this.mymap);
        this.empresaLayer = L.layerGroup().addTo(this.mymap);
        this.mymap.closePopup();
        this.getPedidos();
      } else {
        this.$toasted.show(
          "Servicio de delivery no disponible, por favor actualice la página"
        );
      }
    },

    getEmpresaDatos() {
      let hostUrl = sessionStorage.getItem("HostUrl");
      let idAlmacen = sessionStorage.getItem("IdAlmacen");

      if (hostUrl != null && idAlmacen != null) {
        this.axios
          .get(this.APINODE + "/api/plataforma/empresa", {
            params: {
              HostUrl: hostUrl,
              IdAlmacen: idAlmacen
            }
          })
          .then(res => {
            if (res.data.success === true) {
              this.idEmpresa = res.data.data.IdEmpresa;
              this.empresa = res.data.data;
              this.$socket.connect();
              this.getPedidos();
            }
          })
          .catch(err => {
            this.idEmpresa = null;
            this.empresa = {};
            this.$swal({
              icon: "warning",
              iconColor: "#ffbe55",
              title: "Delivery temporalmente fuera de línea",
              text: "No se pudo conectar con el servidor de delivery.",
              footer: "Cierre automático en 1 segundo",
              width: "430px",
              padding: "1.25rem 1.35rem 1rem",
              timer: 1000,
              timerProgressBar: true,
              showConfirmButton: true,
              confirmButtonText: "Continuar trabajando",
              buttonsStyling: false,
              showCloseButton: true,
              allowOutsideClick: true,
              allowEscapeKey: true,
              backdrop: "rgba(2, 12, 24, 0.46)",
              customClass: {
                container: "pos-delivery-alert-container",
                popup: "pos-delivery-alert",
                icon: "pos-delivery-alert-icon",
                title: "pos-delivery-alert-title",
                htmlContainer: "pos-delivery-alert-copy",
                footer: "pos-delivery-alert-footer",
                timerProgressBar: "pos-delivery-alert-progress",
                confirmButton: "pos-delivery-alert-confirm",
                closeButton: "pos-delivery-alert-close"
              }
            });
          });
      } else {
        this.idEmpresa = null;
        this.empresa = {};
        this.$swal({
          icon: "warning",
          iconColor: "#ffbe55",
          title: "Delivery temporalmente fuera de línea",
          text: "No se pudo validar la conexión con el servicio de delivery.",
          target: document.getElementById("conten"),
          footer: "Cierre automático en 1 segundo",
          width: "430px",
          padding: "1.25rem 1.35rem 1rem",
          timer: 1000,
          timerProgressBar: true,
          showConfirmButton: true,
          confirmButtonText: "Continuar trabajando",
          buttonsStyling: false,
          showCloseButton: true,
          allowOutsideClick: true,
          allowEscapeKey: true,
          backdrop: "rgba(2, 12, 24, 0.46)",
          customClass: {
            container: "pos-delivery-alert-container",
            popup: "pos-delivery-alert",
            icon: "pos-delivery-alert-icon",
            title: "pos-delivery-alert-title",
            htmlContainer: "pos-delivery-alert-copy",
            footer: "pos-delivery-alert-footer",
            timerProgressBar: "pos-delivery-alert-progress",
            confirmButton: "pos-delivery-alert-confirm",
            closeButton: "pos-delivery-alert-close"
          }
        });
      }
    },

    getPedidos() {
      if (this.idEmpresa != null) {
        this.pedidos = [];
        this.audio.loop = true;

        this.axios
          .get(this.APINODE + "/api/plataforma/pedidos", {
            params: {
              IdEmpresa: this.idEmpresa
            }
          })
          .then(res => {
            if (res.data.success === true) {
              this.pedidos = res.data.data;
              if (this.pedidos.filter(p => p.Estado === "E").length > 0) {
                this.audio.play();
              } else {
                this.audio.pause();
              }
              this.title = "(" + this.pedidos.length + ") Pedidos de Delivery";
              this.pedidos.map(p => {
                p.showPopover = false;
              });
              if (this.pedidoIdMapa != null) {
                let existe = this.pedidos.some(
                  p => p.IdPedido === this.pedidoIdMapa
                );
                if (!existe) {
                  if (this.mymap) {
                    this.emitirConsultaMotorizado();
                  }
                }
              } else {
                if (this.mymap) {
                  this.emitirConsultaMotorizado();
                }
              }
            } else if (res.data.success === false) {
              this.audio.pause();
              this.pedidos = [];
              this.title = "Punto de Venta";
              if (this.mymap) {
                this.emitirConsultaMotorizado();
              }
            } else {
              this.audio.pause();
              this.pedidos = [];
              if (this.mymap) {
                this.emitirConsultaMotorizado();
              }
            }
          })
          .catch(err => {
            this.pedidos = [];
            this.audio.pause();
            console.log(err);
            this.title = "Sin Delivery, Actualice";
          });
      } else {
        this.audio.pause();
        this.title = "Sin Delivery, Actualice";
        this.$toasted.show(
          "Servicio de delivery no disponible, por favor actualice la página"
        );
      }
    },

    aceptarPedido(idPedido, idCliente) {
      this.axios
        .post(this.APINODE + "/api/plataforma/pedidos/aceptar", {
          IdPedido: idPedido,
          Usuario: this.usuario || "admin"
        })
        .then(res => {
          if (res.data.success === true) {
            this.emitirEstado(idPedido, idCliente, "PE");
            let pedidoIndex = this.pedidos.findIndex(
              p => p.IdPedido === idPedido
            );
            if (pedidoIndex !== -1) {
              this.$nextTick(() => {
                this.pedidos[pedidoIndex].Estado = "PE";
                this.pedidos[pedidoIndex].UsuarioReg = res.data.usuario;
              });
              setTimeout(() => {
                this.emitirConsultaMotorizado();
              }, 400);
              let pedido = this.pedidos.find(p => p.IdPedido === idPedido);
              if (pedido != undefined) {
                this.$emit("onPagarDelivery", pedido);
                this.show = false;
              }
              setTimeout(() => {
                if (this.pedidos.filter(p => p.Estado === "E").length === 0) {
                  this.audio.pause();
                }
              }, 1000);
            }
          } else if (res.data.success === false) {
            this.getPedidos();
          }
        })
        .catch(err => {
          console.log(err);
        });
    },

    cancelarPedido(idPedido, idCliente) {
      let pedido = this.pedidos[
        this.pedidos.findIndex(p => p.IdPedido === idPedido)
      ];
      this.$swal({
        target: document.getElementById("conten"),
        title:
          "Se cancelará el pedido de: " + pedido.Cliente + " ¿está seguro?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, cancelar",
        cancelButtonText: "No, atrás"
      }).then(result => {
        if (result.isConfirmed) {
          this.axios
            .post(this.APINODE + "/api/plataforma/pedido/cancelar", {
              IdPedido: idPedido
            })
            .then(res => {
              if (res.data.success === true) {
                this.emitirEstado(
                  idPedido,
                  idCliente,
                  "C",
                  pedido.IdMotorizado
                );
                if (this.pedidoIdMapa === idPedido) {
                  this.emitirConsultaMotorizado();
                }
                this.$toasted.success("Pedido cancelado!");
                this.getPedidos();
              } else if (res.data.success === false) {
                this.getPedidos();
                this.$toasted.success(
                  "El pedido tiene otro estado, se actualizarán los pedidos!"
                );
              }
            })
            .catch(err => {
              console.log(err);
            });
        }
      });
    },

    rechazarPedido(idpedido) {
      let pedido = this.pedidos[
        this.pedidos.findIndex(p => p.IdPedido === idpedido)
      ];
      let r = confirm(
        "¿Está seguro de rechazar la solicitud de " + pedido.Cliente + "?"
      );
      if (r) {
        this.axios
          .post(this.APINODE + "/api/plataforma/pedido/rechazar", {
            IdPedido: pedido.IdPedido
          })
          .then(res => {
            if (res.data.success === true) {
              this.emitirEstado(
                pedido.IdPedido,
                pedido.IdCliente,
                "C",
                pedido.IdMotorizado
              );
              this.$toasted.success("¡Pedido rechazado!");
              this.getPedidos();
            } else if (res.data.success === false) {
              this.$toasted.success(res.data.msg);
              this.getPedidos();
            }
          })
          .catch(err => {
            console.log(err);
          });
      }
    },

    volverRealizarVenta(idpedido) {
      let pedido = this.pedidos.find(p => p.IdPedido === idpedido);
      if (pedido != undefined) {
        this.axios
          .get(this.API + "venta/pedido/existe", {
            params: {
              IdPedido: idpedido
            }
          })
          .then(response => {
            if (response.data.idDocVenta) {
              this.$swal({
                icon: "info",
                title: "Ya existe una venta para este pedido",
                target: document.getElementById("conten"),
                html:
                  "Tipo: <strong>" +
                  response.data.TipoDoc +
                  "</strong><br>Comprobante: <strong>" +
                  response.data.Serie +
                  "-" +
                  response.data.Numero +
                  "</strong><br>Fecha y Hora: <strong>" +
                  response.data.FechaDoc +
                  "</strong><br>Realizado por: <strong>" +
                  response.data.UsuarioReg +
                  "</strong>",
                showConfirmButton: true,
                showDenyButton: true,
                confirmButtonText: "Ir a reimpresión de documentos",
                confirmButtonColor: "#3880ff",
                denyButtonText: "Ir a registro de ventas",
                footer:
                  "Puede anular la venta en el registro de ventas e intentarlo nuevamente."
              }).then(result => {
                if (result.isConfirmed) {
                  window.open("/views/ve_reimpresionDocumentos.php", "_blank");
                } else if (result.isDenied) {
                  window.open("/views/ve_regventaform.php", "_blank");
                }
              });
            } else {
              this.$emit("onPagarDelivery", pedido);
              this.show = false;
            }
          })
          .catch(error => {
            this.$toasted.show("Hubo un error, no hay conexión");
          });
      }
    },

    emitirEstado(idPedido, idCliente, estado, idmotorizado = null) {
      this.$socket.emit("estado-pedido-emitir-plataforma", {
        IdCliente: idCliente,
        IdPedido: idPedido,
        Estado: estado,
        IdMotorizado: idmotorizado
      });
    },

    emitirNuevoViaje(IdMotorizado, IdCliente, Cliente) {
      this.$socket.emit("nuevo-viaje-solicitado", {
        idmotorizado: IdMotorizado,
        idpedido: IdCliente,
        cliente: Cliente
      });
    },

    emitirConsultaMotorizado() {
      this.mostrarMotorizados = true;
      this.mostrarCliente = "";
      this.pedidoMotorizadoId = null;
      this.pedidoIdMapa = null;
      if (this.empresaLayer !== undefined) {
        this.empresaLayer.clearLayers();
      }
      if (this.clienteLayer !== undefined) {
        this.clienteLayer.clearLayers();
      }
      this.$socket.emit("motorizado-on-consulta", {
        facturaurl: this.empresa.FacturaUrl,
        idalmacen: this.empresa.IdAlmacen
      });
    },

    mostrarClienteMapa(idPedido) {
      this.mostrarMotorizados = false;
      this.pedidoIdMapa = idPedido;
      this.motorizadosOnline.map(e => {
        if (e.marker != null) {
          this.mymap.removeLayer(e.marker);
        }
      });
      this.motorizadosOnline = [];
      let pedido = this.pedidos[
        this.pedidos.findIndex(p => p.IdPedido === idPedido)
      ];
      if (this.empresaLayer !== undefined) {
        this.empresaLayer.clearLayers();
        L.marker(
          [Number(pedido.EmpresaLatitud), Number(pedido.EmpresaLongitud)],
          {
            icon: this.iconCasa
          }
        )
          .addTo(this.empresaLayer)
          .bindPopup("<b>" + pedido.RazonSocial + "</b>")
          .openPopup();
      }
      if (this.clienteLayer !== undefined) {
        this.clienteLayer.clearLayers();
        L.marker([Number(pedido.Latitud), Number(pedido.Longitud)])
          .addTo(this.clienteLayer)
          .bindPopup("<b>" + pedido.Cliente + "</b>")
          .openPopup();
      }
      if (pedido.IdMotorizado != null) {
        this.pedidoMotorizadoId = pedido.IdMotorizado;
      }
      this.mostrarCliente = "MOSTRANDO PEDIDO DE: " + pedido.Cliente;
    },

    getMotorizados(idpedido) {
      this.pedidos.map(p => (p.showPopover = false));
      let indexPedido = this.pedidos.findIndex(p => p.IdPedido === idpedido);
      if (indexPedido !== -1) {
        this.pedidos[indexPedido].showPopover = true;
      }
      if (this.idEmpresa != null) {
        this.axios
          .get(this.APINODE + "/api/motorizados", {
            params: {
              IdEmpresa: this.idEmpresa
            }
          })
          .then(res => {
            if (res.data.success === true) {
              this.motorizados = res.data.motorizados;
              this.$socket.emit("motorizado-on-consulta", {
                facturaurl: this.empresa.FacturaUrl,
                idalmacen: this.empresa.IdAlmacen
              });
            } else if (res.data.success === false) {
              this.motorizados = [];
            }
          })
          .catch(err => {
            console.log(err);
          });
      } else {
        this.$toasted.show(
          "Servicio de delivery no disponible, por favor actualice la página"
        );
      }
    },

    asignarMotorizado(idpedido, idcliente, cliente, idmotorizado, motorizado) {
      this.axios
        .post(this.APINODE + "/api/plataforma/pedido/motorizado/asignar", {
          IdPedido: idpedido,
          IdMotorizado: idmotorizado,
          Motorizado: motorizado
        })
        .then(res => {
          if (res.data.success === 1) {
            this.$toasted.show(res.data.msg);
            this.getMotorizados(idpedido);
            this.getPedidos();
          } else if (res.data.success === 2) {
            this.$toasted.success("¡Motorizado Asignado!");
            this.emitirNuevoViaje(idmotorizado, idcliente, cliente);
            this.getPedidos();
          } else if (res.data.success === 3) {
            this.getPedidos();
          }
        })
        .catch(err => {
          console.log(err);
        });
    },

    cambiarMotorizado(
      idpedido,
      idcliente,
      cliente,
      idmotorizadonuevo,
      motorizadonuevo,
      idmotorizadoanterior,
      motorizadoanterior
    ) {
      this.axios
        .post(this.APINODE + "/api/plataforma/pedido/motorizado/cambiar", {
          IdPedido: idpedido,
          IdMotorizadoNuevo: idmotorizadonuevo,
          MotorizadoNuevo: motorizadonuevo,
          IdMotorizadoAnterior: idmotorizadoanterior,
          MotorizadoNuevoAnterior: motorizadoanterior
        })
        .then(res => {
          if (res.data.success === 1) {
            this.$toasted.show(res.data.msg);
            this.getMotorizados(idpedido);
            this.getPedidos();
          } else if (res.data.success === 2) {
            this.$toasted.success("¡Motorizado Cambiado!");
            this.emitirNuevoViaje(idmotorizadonuevo, idcliente, cliente);
            this.getPedidos();
          } else if (res.data.success === 3) {
            this.getPedidos();
          }
        })
        .catch(err => {
          console.log(err);
        });
    },

    enviarPreparar() {
      this.axios
        .post(this.APINODE + "/api/pedido/preparar", {
          IdPedido: this.idPedidoSelect
        })
        .then(res => {
          if (res.data.success === 1) {
            this.axios
              .post(this.API + "preorden/plataforma", {
                InfoPedido: this.infoPedido
              })
              .then(resp => {
                if (resp.data.insertId) {
                  window.open(
                    "/imprimir/index.php?IdMesa=" + resp.data.IdMesa,
                    "_blank"
                  );
                  this.$toasted.success(res.data.msg);
                  this.$refs.modalPedido.hide();
                }
              })
              .catch(error => {});
          } else if (res.data.success === 3) {
            this.$refs.modalPedido.hide();
            this.$toasted.show(res.data.msg);
            this.getPedidos();
          } else if (res.data.success === 2) {
            this.$toasted.show(res.data.msg);
          }
        })
        .catch(err => {
          console.log(err);
        });
    },

    cerrarModal() {
      this.$refs.modalPedidos.hide();
    }
  },

  components: {}
};
</script>

<style>
#mapid {
  width: 100%;
  height: 80vh;
}
.modal-header .close {
  /*display:none;*/
}
.container-print * {
  width: 75mm;
  padding: 3mm 0.5mm 3mm 0.5m;
  box-sizing: border-box;
  font-size: 3.5mm;
  font-family: monospace;
}
.popover {
  max-width: 450px !important;
}
#modalPedidos .modal-dialog {
  max-width: 95% !important;
}
.parpadea {
  animation-name: parpadeo;
  animation-duration: 1s;
  animation-timing-function: linear;
  animation-iteration-count: infinite;
  -webkit-animation-name: parpadeo;
  -webkit-animation-duration: 1s;
  -webkit-animation-timing-function: linear;
  -webkit-animation-iteration-count: infinite;
  color: black !important;
  border-color: black !important;
  font-weight: bold !important;
}
@-moz-keyframes parpadeo {
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes parpadeo {
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@keyframes parpadeo {
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

/* Alerta compacta de conectividad: informativa y no bloqueante. */
.pos-delivery-alert-container {
  backdrop-filter: blur(3px);
  -webkit-backdrop-filter: blur(3px);
}

.swal2-popup.pos-delivery-alert {
  position: relative;
  overflow: hidden;
  border: 1px solid rgba(103, 226, 245, 0.30);
  border-radius: 22px;
  color: #edfaff;
  background:
    radial-gradient(circle at 8% 0%, rgba(8, 214, 236, 0.22), transparent 12rem),
    radial-gradient(circle at 100% 110%, rgba(246, 56, 109, 0.18), transparent 13rem),
    linear-gradient(145deg, #071b2a 0%, #0c2137 58%, #231628 100%);
  box-shadow: 0 28px 70px rgba(0, 5, 16, 0.44), 0 0 28px rgba(8, 214, 236, 0.10), inset 0 1px 0 rgba(255,255,255,.10);
}

.swal2-popup.pos-delivery-alert::before {
  position: absolute;
  top: 0;
  right: 22px;
  left: 22px;
  height: 2px;
  border-radius: 999px;
  content: "";
  background: linear-gradient(90deg, transparent, #08d6ec, #7957ff, #f6386d, transparent);
  background-size: 220% 100%;
  filter: drop-shadow(0 0 7px rgba(8,214,236,.55));
  animation: deliveryAlertEnergy 1.5s ease-in-out infinite;
}

.swal2-popup .pos-delivery-alert-icon {
  width: 3.35em;
  height: 3.35em;
  margin: .3em auto .55em;
  border-width: 2px;
  background: rgba(255,190,85,.07);
  box-shadow: 0 0 0 7px rgba(255,190,85,.055), 0 0 26px rgba(255,190,85,.15);
  font-size: .92rem;
}

.swal2-popup .pos-delivery-alert-title {
  padding: 0;
  color: #ffffff;
  font-size: 1.18rem;
  font-weight: 850;
  line-height: 1.18;
  letter-spacing: -.015em;
}

.swal2-popup .pos-delivery-alert-copy {
  margin: .4rem 0 0;
  padding: 0 .35rem;
  color: #b9d4e4;
  font-size: .82rem;
  line-height: 1.45;
}

.swal2-popup .pos-delivery-alert-footer {
  margin: .75rem 0 0;
  padding: .62rem 0 0;
  border-top-color: rgba(112,220,240,.14);
  color: #789bb0;
  font-size: .66rem;
  font-weight: 700;
  letter-spacing: .035em;
}

.swal2-popup .pos-delivery-alert-progress {
  height: 3px;
  background: linear-gradient(90deg, #08d6ec, #4c6fff, #f6386d);
  box-shadow: 0 0 12px rgba(8,214,236,.42);
}

.swal2-popup.pos-delivery-alert::after {
  position: absolute;
  top: 13px;
  left: 17px;
  padding: 4px 8px;
  border: 1px solid rgba(76, 225, 239, .24);
  border-radius: 999px;
  content: "DELIVERY  •  CONECTIVIDAD";
  color: #76e9f6;
  background: rgba(5, 48, 67, .52);
  font-size: .52rem;
  font-weight: 850;
  letter-spacing: .1em;
}

.swal2-popup .swal2-actions {
  margin: .85rem auto 0;
}

.swal2-popup .pos-delivery-alert-confirm {
  min-height: 36px;
  padding: 7px 17px;
  border: 1px solid rgba(120, 235, 249, .42);
  border-radius: 11px;
  color: #fff;
  background: linear-gradient(125deg, #0da6bf 0%, #3672e8 56%, #7157e7 100%);
  box-shadow: 0 8px 20px rgba(30, 112, 210, .25), inset 0 1px 0 rgba(255,255,255,.24);
  font-size: .72rem;
  font-weight: 850;
  letter-spacing: .025em;
  cursor: pointer;
  transition: transform .18s ease, filter .18s ease, box-shadow .18s ease;
}

.swal2-popup .pos-delivery-alert-confirm:hover,
.swal2-popup .pos-delivery-alert-confirm:focus {
  filter: brightness(1.12);
  transform: translateY(-1px);
  box-shadow: 0 11px 24px rgba(30, 132, 220, .34), 0 0 0 3px rgba(69, 215, 239, .1);
  outline: 0;
}

.swal2-popup .pos-delivery-alert-close {
  top: 7px;
  right: 7px;
  width: 34px;
  height: 34px;
  border-radius: 10px;
  color: #92b9cd;
  font-size: 1.45rem;
  transition: color .18s ease, background .18s ease, transform .18s ease;
}

.swal2-popup .pos-delivery-alert-close:hover {
  color: #fff;
  background: rgba(246, 56, 109, .18);
  transform: rotate(5deg);
}

@keyframes deliveryAlertEnergy {
  0%, 100% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
}

@media (max-width: 480px) {
  .swal2-popup.pos-delivery-alert {
    width: calc(100vw - 26px) !important;
    padding: 1rem .85rem .75rem !important;
    border-radius: 18px;
  }
}
</style>
